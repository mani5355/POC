package com.example.demo.bean;

public class Student {

	private String name;

	private Integer classStandard;

	private Character section;

	private Integer roll;

	private String email;

	private Integer mobile;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getClassStandard() {
		return classStandard;
	}

	public void setClassStandard(Integer classStandard) {
		this.classStandard = classStandard;
	}

	public Character getSection() {
		return section;
	}

	public void setSection(Character section) {
		this.section = section;
	}

	public Integer getRoll() {
		return roll;
	}

	public void setRoll(Integer roll) {
		this.roll = roll;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getMobile() {
		return mobile;
	}

	public void setMobile(Integer mobile) {
		this.mobile = mobile;
	}

}
