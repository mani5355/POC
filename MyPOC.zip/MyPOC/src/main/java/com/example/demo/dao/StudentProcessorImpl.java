package com.example.demo.dao;

import java.util.List;

import com.example.demo.bean.Student;

public class StudentProcessorImpl implements IStudentProcessor{

	@Override
	public List<Student> getAllStudentDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getSingleStudentDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
