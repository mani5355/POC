package com.example.demo.dao;

//testing lambda expression for functional interface.
public interface TestLambdaExpression {

	public static void main(String[] args) {

		Check testLambdaExpression = (x, y) -> {
			return x + y;

		};

		System.out.println(testLambdaExpression.addTwoInt(8, 9));
	}

}

//Here main mtd treats as normal mrthod
class A implements TestLambdaExpression {

	public void main() {

		System.out.println("Inside normal main method.");
	}
}

@FunctionalInterface
interface Check {

	int addTwoInt(int x, int y);

	String toString();

	// Object clone(); -> not public mtd of Object class

//	public void main(String[] args);
}

/*
 * class A implements Check{
 * 
 * @Override public void main(String[] args) { System.out.println(10); }
 * 
 * public static void main1(String[] args) { System.out.println(10); }
 * 
 * 
 * }
 */