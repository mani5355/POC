
package com.example.demo.dao;

/**
 * The Class TestInterfaceDefaultStatic.
 */
//Default : we can have implementation using this keyword in an interface..
//Static : allows implementations but it is part of the interface..cant override them.

/*
 * Q: How diamond problem or multiple inheritance handled here?.. while
 * implementing both interfaces having default mtd with same name...it will
 * throw compilation error saying must override that default
 * mtd("Duplicate default methods named show with the parameters () and () are inherited from the types Test2 and Test1"
 * )...by doing that u r giving a new definition to the default mtd...so problem
 * solved.. :)
 */

/*
 * Important points about java interface default methods:
 * 
 * 
 * Java interface default methods will help us in extending interfaces without
 * having the fear of breaking implementation classes. Java interface default
 * methods has bridge down the differences between interfaces and abstract
 * classes. Java 8 interface default methods will help us in avoiding utility
 * classes, such as all the Collections class method can be provided in the
 * interfaces itself. Java interface default methods will help us in removing
 * base implementation classes, we can provide default implementation and the
 * implementation classes can chose which one to override. One of the major
 * reason for introducing default methods in interfaces is to enhance the
 * Collections API in Java 8 to support lambda expressions. If any class in the
 * hierarchy has a method with same signature, then default methods become
 * irrelevant. A default method cannot override a method from java.lang.Object.
 * The reasoning is very simple, it’s because Object is the base class for all
 * the java classes. So even if we have Object class methods defined as default
 * methods in interfaces, it will be useless because Object class method will
 * always be used. That’s why to avoid confusion, we can’t have default methods
 * that are overriding Object class methods. Java interface default methods are
 * also referred to as Defender Methods or Virtual extension methods.
 */
/*
 * Important points about java interface static method:
 * 
 * Java interface static method is part of interface, we can’t use it for
 * implementation class objects. Java interface static methods are good for
 * providing utility methods, for example null check, collection sorting etc.
 * Java interface static method helps us in providing security by not allowing
 * implementation classes to override them. We can’t define interface static
 * method for Object class methods, we will get compiler error as “This static
 * method cannot hide the instance method from Object”. This is because it’s not
 * allowed in java, since Object is the base class for all the classes and we
 * can’t have one class level static method and another instance method with
 * same signature. We can use java interface static methods to remove utility
 * classes such as Collections and move all of it’s static methods to the
 * corresponding interface, that would be easy to find and use.
 */

/*
 * Does an interface extend Object class in java.?
 * 
 * You may have come across this question while reading about interfaces in
 * java. You may also know that only classes in java are inherited from
 * java.lang.Object class. Interfaces in java don’t inherit from Object class.
 * They don’t have default parent like classes in java. But, following two cases
 * may surprise you.
 * 
 * 
 * Case 1 :
 * 
 * If an interface does not extend Object class, then why we can call methods of
 * Object class on interface variable like below.
 * 
 * interface A {
 * 
 * }
 * 
 * class InterfaceAndObjectClass { public static void main(String[] args) { A a
 * = null;
 * 
 * a.equals(null);
 * 
 * a.hashCode();
 * 
 * a.toString(); } }
 * 
 * Case 2 :
 * 
 * If an interface does not extend Object class, then why the methods of Object
 * class are visible in interface.?
 * 
 * interface A {
 * 
 * @Override public boolean equals(Object obj);
 * 
 * @Override public int hashCode();
 * 
 * @Override public String toString(); }
 * 
 * Explanation :
 * 
 * This is because, for every public method in Object class, there is an
 * implicit abstract and public method declared in every interface which does
 * not have direct super interfaces. This is the standard Java Language
 * Specification which states like this,
 * 
 * “If an interface has no direct superinterfaces, then the interface implicitly
 * declares a public abstract member method m with signature s, return type r,
 * and throws clause tcorresponding to each public instance method m with
 * signature s, return type r, and throws clause t declared in Object, unless a
 * method with the same signature, same return type, and a compatible throws
 * clause is explicitly declared by the interface.”
 */
public class TestInterfacDefaultStatic {

	public static void main(String[] args) {

		TestDiamondProblemWithDefaultMtd ab = new TestDiamondProblemWithDefaultMtd();
		TestDiamondProblemWithDefaultMtd.print();
		ab.show();

	}

}

interface Test1 {

	void test1();

	////String toString();???
	
	default void show() {

		System.out.println("inside show mtd of Test1");
	}

	static void show1() {

		System.out.println("inside show1 mtd of Test1");
	}

}

interface Test2 {

	void test2();

	default void show() {

		System.out.println("inside show mtd of Test2");
		toString();/////////////////////////?????????

	}
	
	// A default method cannot override a method from java.lang.Object
	/*
	 * If any class in the hierarchy has a method with same signature, then default
	 * methods become irrelevant. A default method cannot override a method from
	 * java.lang.Object. The reasoning is very simple, it’s because Object is the
	 * base class for all the java classes. So even if we have Object class methods
	 * defined as default methods in interfaces, it will be useless because Object
	 * class method will always be used. That’s why to avoid confusion, we can’t
	 * have default methods that are overriding Object class methods.
	 */
	
//	default String toString() {
//		System.out.println("inside show mtd of Test2");
//		return null;
//	}
	 
    String toString(Object obj);/////////////????????
    
	static void show1() {

		System.out.println("inside show1 mtd of Test2");
	}

}

class TestDiamondProblemWithDefaultMtd implements Test1, Test2 {

	@Override
	public void test2() {
		System.out.println("tset2");

	}

	@Override
	public void test1() {
		System.out.println("test1");

	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		Test1.show1();
	}

	static void print() {

		System.out.println("print");

	}

	@Override
	public String toString(Object obj) {
		// TODO Auto-generated method stub
		return null;
	}

}
