package com.example.demo.dao;

public class MainClass {

	public static void main(String[] args) {

		System.out.println("2");
		int count;
		for (int i = 3; i < 20; i++) {
			count = 0;
			for (int j = 2; j < i; j++) {

				if (i % j == 0) {

					count++;

				}
			}
			if (count == 0) {
				System.out.println(i);
			}
		}

	}

}
