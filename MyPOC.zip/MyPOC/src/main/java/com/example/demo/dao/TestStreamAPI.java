package com.example.demo.dao;

//The lazy processing is based on a 'process-only, on-demand' strategy.
public class TestStreamAPI {

}
