package com.example.demo.dao;

import java.util.List;

import com.example.demo.bean.Student;

public interface IStudentProcessor {

	 List<Student> getAllStudentDetails();
	
	 Student getSingleStudentDetails();
	
}
